package lancerDes;

public enum Score {
	GAGNE, 
	PERDU;

}
