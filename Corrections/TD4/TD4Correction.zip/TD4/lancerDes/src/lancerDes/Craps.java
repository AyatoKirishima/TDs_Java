package lancerDes;

public class Craps {
	private De d1;
	private De d2;
	
	public Craps()
	{
	  d1=new De();
	  d2=new De();
	}
	
   	public De getD1() {
		return d1;
	}



	public void setD1(De d1) {
		this.d1 = d1;
	}

	public De getD2() {
		return d2;
	}


	public void setD2(De d2) {
		this.d2 = d2;
	}

	public void lancer()
   	{
   	 d1.lancer();
     d2.lancer();	
   	}
   	
   	public int somme ()
   	{
   		return d1.getvaleurFace() + d2.getvaleurFace();
   	}
   	
   	public String toString()
   	{
   		return " lancer de De 1 :"+ d1.toString()+ " lancer de De 2 :"+ d2.toString();
   	}
   	

   	public Score jeuCraps()
   	{  int s1= this.somme();
   	   int s2 = 0 ; 
   	   Score resultat;
	   if  ((s1==7)||(s1==11)) resultat=Score.GAGNE;
   	   else if ((s1==2)||(s1==3)||(s1==12)) resultat=Score.PERDU;
   	   else{ 
   		   do{ 
   			      this.lancer();
   			      s2=this.somme();
   			     // System.out.println( this.toString());
   		       } while((s2!=7)&&(s2!=s1));
	   
	    if (s2==7) resultat= Score.PERDU;
	    else resultat= Score.GAGNE;
   	   }
	   	return resultat;

   	}
 }
