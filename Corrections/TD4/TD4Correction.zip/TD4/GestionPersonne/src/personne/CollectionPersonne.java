package personne;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionPersonne {
	private ArrayList<Personne> c;

	/**
	 * @param c
	 */
	public CollectionPersonne() {
		c=new ArrayList <Personne>();
	}
	
	public void ajouter(Personne p){
	c.add(p);
	}
	

	public void afficher()
	{
		Iterator<Personne> it=c.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	
	

}
