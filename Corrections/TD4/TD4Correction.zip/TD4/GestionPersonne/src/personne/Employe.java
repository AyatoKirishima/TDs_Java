package personne;

public class Employe extends Personne {
	
	private int anciennete;
	/**
	 * @param nom
	 * @param prenom
	 * @param dnaissance
	 * @param anciennete
	 */
	public Employe(String nom, String prenom, Date dnaissance, int anciennete) {
		super(nom, prenom, dnaissance);
		this.anciennete = anciennete;
	}
	public int getAnciennete() {
		return anciennete;
	}
	public void setAnciennete(int anciennete) {
		this.anciennete = anciennete;
	}
	@Override
	public String toString() {
		return "Employe ["+super.toString()+"anciennete=" + anciennete + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof Employe))
			return false;
		Employe other = (Employe) obj;
		if (anciennete != other.anciennete)
			return false;
		return true;
	}
	
	
  
	


	

}
