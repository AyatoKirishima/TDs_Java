package personne;

public class Personne {
	protected String nom;
	protected String prenom;
	protected Date dnaissance;
	/**
	 * @param nom
	 * @param prenom
	 * @param dnaissance
	 */
	public Personne(String nom, String prenom, Date dnaissance) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.dnaissance = dnaissance;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public Date getDnaissance() {
		return dnaissance;
	}
	public void setDnaissance(Date dnaissance) {
		this.dnaissance = dnaissance;
	}
	
	@Override
	public String toString() {
		return "Personne [nom=" + nom + ", prenom=" + prenom + ", dnaissance="
				+ dnaissance + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Personne))
			return false;
		Personne other = (Personne) obj;
		if (dnaissance == null) {
			if (other.dnaissance != null)
				return false;
		} else if (!dnaissance.equals(other.dnaissance))
			return false;
		if (nom == null) {
			if (other.nom != null)
				return false;
		} else if (!nom.equals(other.nom))
			return false;
		if (prenom == null) {
			if (other.prenom != null)
				return false;
		} else if (!prenom.equals(other.prenom))
			return false;
		return true;
	}

	
}
