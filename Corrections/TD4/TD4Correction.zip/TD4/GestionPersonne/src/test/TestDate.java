package test;

import personne.Date;



public class TestDate {
	

	
	public static void main(String args [])
	{
		Date d1=new Date(10,12,1964);
		Date d2=new Date(28,3,2014);
		System.out.println("la valeur de nb est : "+d1.difference(d2));
	} 

}
